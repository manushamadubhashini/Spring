package lk.ijse.bean;

import org.springframework.stereotype.Component;


public class MyConnection {
    public MyConnection(){
        System.out.println("My Connection Object Created");
    }
}
