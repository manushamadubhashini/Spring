package lk.ijse.bean;

public interface Agreement {
    public void chat();
}
