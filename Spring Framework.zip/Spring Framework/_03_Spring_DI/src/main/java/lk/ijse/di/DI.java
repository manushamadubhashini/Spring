package lk.ijse.di;

public interface DI {
    public void sayHello();
}
