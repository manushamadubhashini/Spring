package lk.ijse.di;

public interface DiInterface {
    void inject(DI test1);
}
